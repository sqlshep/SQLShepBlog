﻿using System;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Generic;
using System.Net;
using Microsoft.Azure.Cosmos;
using Bogus;
using Newtonsoft.Json;

namespace CosmosGettingStartedTutorial
{
    class Program
    {
        // The Azure Cosmos DB endpoint for running this sample.
        private static readonly string EndpointUri = ConfigurationManager.AppSettings["EndPointUri"];

        // The primary key for the Azure Cosmos account.
        private static readonly string PrimaryKey = ConfigurationManager.AppSettings["PrimaryKey"];

        // The Cosmos client instance
        private Microsoft.Azure.Cosmos.CosmosClient cosmosClient;

        // The database we will create
        private Microsoft.Azure.Cosmos.Database database;

        // The container we will create.
        private Microsoft.Azure.Cosmos.Container container;

        // The name of the database and container we will create
        private string databaseId = "FamilyDatabase";
        private string containerId = "FamilyContainer";


        // <Main>
        public static async Task Main(string[] args)
        {
            

            try
            {
                Console.WriteLine("Beginning operations...\n");
                Program p = new Program();
                await p.GetStartedDemoAsync();

            }
            catch (CosmosException cosmosException)
            {
                Console.WriteLine("Cosmos Exception with Status {0} : {1}\n", cosmosException.StatusCode, cosmosException);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e);
            }
            finally
            {
                Console.WriteLine("End of demo.");
                //Console.ReadKey();
            }
        }


        // </Main>

        // <GetStartedDemoAsync>
        /// <summary>
        /// Entry point to call methods that operate on Azure Cosmos DB resources in this sample
        /// </summary>
        public async Task GetStartedDemoAsync()
        {

            // Create a new instance of the Cosmos Client
            this.cosmosClient = new CosmosClient(EndpointUri, PrimaryKey);
            await this.CreateDatabaseAsync();
            await this.CreateContainerAsync();
            int y = 0;
            while (y < 5000)
            {
                await this.AddItemsToContainerAsync();
                y++;
            }
            //await this.QueryItemsAsync();
            //await this.ReplaceFamilyItemAsync();
            //await this.DeleteFamilyItemAsync();
            //await this.DeleteDatabaseAndCleanupAsync();

        }
        // </GetStartedDemoAsync>

        // <CreateDatabaseAsync>
        /// <summary>
        /// Create the database if it does not exist
        /// </summary>
        private async Task CreateDatabaseAsync()
        {
            // Create a new database
            this.database = await this.cosmosClient.CreateDatabaseIfNotExistsAsync(databaseId);
            Console.WriteLine("Created Database: {0}\n", this.database.Id);
        }
        // </CreateDatabaseAsync>

        // <CreateContainerAsync>
        /// <summary>
        /// Create the container if it does not exist. 
        /// Specifiy "/LastName" as the partition key since we're storing family information, to ensure good distribution of requests and storage.
        /// </summary>
        /// <returns></returns>
        private async Task CreateContainerAsync()
        {
            // Create a new container
            this.container = await this.database.CreateContainerIfNotExistsAsync(containerId, "/LastName");
            Console.WriteLine("Created Container: {0}\n", this.container.Id);
        }
        // </CreateContainerAsync>

        // <AddItemsToContainerAsync>
        /// <summary>
        /// Add Family items to the container
        /// </summary>
        private async Task AddItemsToContainerAsync()
        {

            Record newRecords = new()
            {

            };

            //Set the randomzier seed if you wish to generate repeatable data sets.
            Randomizer.Seed = new Random();

             var fruit = new[] { "apple", "banana", "orange", "strawberry", "kiwi" };

            var orderIds = 0;
            var testOrders = new Faker<Order>()
               //Ensure all properties have rules. By default, StrictMode is false
               //Set a global policy by using Faker.DefaultStrictMode if you prefer.
               .StrictMode(true)
               //OrderId is deterministic
               .RuleFor(o => o.OrderId, f => orderIds++)
               //Pick some fruit from a basket
               .RuleFor(o => o.Item, f => f.PickRandom(fruit))
               //A random quantity from 1 to 10
               .RuleFor(o => o.Quantity, f => f.Random.Number(1, 10))
               //A nullable int? with 80% probability of being null.
               //The .OrNull extension is in the Bogus.Extensions namespace.
               .RuleFor(o => o.LotNumber, f => f.Random.Int(0, 100).OrNull(f, .8f));

            var userIds = 0;
            Random rnd = new Random();
            userIds = rnd.Next();

            var testUsers = new Faker<User>()
               //Optional: Call for objects that have complex initialization
               .CustomInstantiator(f => new User(userIds++, f.Random.Replace("###-##-####")))

               //Basic rules using built-in generators
               .RuleFor(u => u.FirstName, f => f.Name.FirstName())
               .RuleFor(u => u.LastName, f => f.Name.LastName())
               .RuleFor(u => u.Avatar, f => f.Internet.Avatar())
               .RuleFor(u => u.UserName, (f, u) => f.Internet.UserName(u.FirstName, u.LastName))
               .RuleFor(u => u.Email, (f, u) => f.Internet.Email(u.FirstName, u.LastName))
               .RuleFor(u => u.SomethingUnique, f => $"Value {f.UniqueIndex}")
               .RuleFor(u => u.SomeGuid, Guid.NewGuid())

               //Use an enum outside scope.
               .RuleFor(u => u.Gender, f => f.PickRandom<Gender>())
               //Use a method outside scope.
               .RuleFor(u => u.CartId, f => Guid.NewGuid())
               //Compound property with context, use the first/last name properties
               .RuleFor(u => u.FullName, (f, u) => u.FirstName + " " + u.LastName)
               //And composability of a complex collection.
               .RuleFor(u => u.Orders, f => testOrders.Generate(2))
               //After all rules are applied finish with the following action
               .FinishWith((f, u) =>
               {
                   Console.WriteLine("User ID! Id={0}", u.Id);

                   newRecords.Id = u.Id.ToString() ;
                   newRecords.FirstName  = u.FirstName;
                   newRecords.LastName = u.LastName;
                   newRecords.FullName = u.FullName;
                   newRecords.UserName = u.UserName;
                   newRecords.Email = u.Email;
                   newRecords.SomethingUnique = u.SomethingUnique;
                   newRecords.Avatar = u.Avatar;
                   newRecords.CartId = u.CartId;
                   newRecords.SSN = u.SSN;
                   newRecords.Gender = u.Gender;


               });


            var user = testUsers.Generate(1);
            //dump json to screen
            //user.Dump();

            try
            {
                // Read the item to see if it exists.  
                ItemResponse<Record> recordsResponse = await this.container.ReadItemAsync<Record>(newRecords.Id, new PartitionKey(newRecords.LastName));
                Console.WriteLine("Item in database with id: {0} already exists\n", recordsResponse.Resource.Id);
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                // Create an item in the container representing the Andersen family. Note we provide the value of the partition key for this item, which is "Andersen"
                ItemResponse<Record> recordsResponse = await this.container.CreateItemAsync<Record>(newRecords, new PartitionKey(newRecords.LastName));

                // Note that after creating the item, we can access the body of the item with the Resource property off the ItemResponse. We can also access the RequestCharge property to see the amount of RUs consumed on this request.
                //Console.WriteLine("Created item in database with id: {0} Operation consumed {1} RUs.\n", recordsResponse.Resource.Id, recordsResponse.RequestCharge);
                //Console.WriteLine(recordsResponse.Resource.Id, recordsResponse.RequestCharge);
            }


        }
        // </AddItemsToContainerAsync>

        // <QueryItemsAsync>
        /// <summary>
        /// Run a query (using Azure Cosmos DB SQL syntax) against the container
        /// </summary>
        private async Task QueryItemsAsync()
        {
            var sqlQueryText = "SELECT * FROM c WHERE c.LastName = 'Andersen'";

            Console.WriteLine("Running query: {0}\n", sqlQueryText);

            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
            using FeedIterator<Family> queryResultSetIterator = this.container.GetItemQueryIterator<Family>(queryDefinition);

            List<Family> families = new List<Family>();

            while (queryResultSetIterator.HasMoreResults)
            {
                FeedResponse<Family> currentResultSet = await queryResultSetIterator.ReadNextAsync();
                foreach (Family family in currentResultSet)
                {
                    families.Add(family);
                    Console.WriteLine("\tRead {0}\n", family);
                }
            }
        }
        // </QueryItemsAsync>

        // <ReplaceFamilyItemAsync>
        /// <summary>
        /// Replace an item in the container
        /// </summary>
        private async Task ReplaceFamilyItemAsync()
        {
            ItemResponse<Family> wakefieldFamilyResponse = await this.container.ReadItemAsync<Family>("Wakefield.7", new PartitionKey("Wakefield"));
            var itemBody = wakefieldFamilyResponse.Resource;
            
            // update registration status from false to true
            itemBody.IsRegistered = true;
            // update grade of child
            itemBody.Children[0].Grade = 6;

            // replace the item with the updated content
            wakefieldFamilyResponse = await this.container.ReplaceItemAsync<Family>(itemBody, itemBody.Id, new PartitionKey(itemBody.LastName));
            Console.WriteLine("Updated Family [{0},{1}].\n \tBody is now: {2}\n", itemBody.LastName, itemBody.Id, wakefieldFamilyResponse.Resource);
        }
        // </ReplaceFamilyItemAsync>

        // <DeleteFamilyItemAsync>
        /// <summary>
        /// Delete an item in the container
        /// </summary>
        private async Task DeleteFamilyItemAsync()
        {
            var partitionKeyValue = "Wakefield";
            var familyId = "Wakefield.7";

            // Delete an item. Note we must provide the partition key value and id of the item to delete
            ItemResponse<Family> wakefieldFamilyResponse = await this.container.DeleteItemAsync<Family>(familyId,new PartitionKey(partitionKeyValue));
            Console.WriteLine("Deleted Family [{0},{1}]\n", partitionKeyValue, familyId);
        }
        // </DeleteFamilyItemAsync>

        // <DeleteDatabaseAndCleanupAsync>
        /// <summary>
        /// Delete the database and dispose of the Cosmos Client instance
        /// </summary>
        private async Task DeleteDatabaseAndCleanupAsync()
        {
            DatabaseResponse databaseResourceResponse = await this.database.DeleteAsync();
            // Also valid: await this.cosmosClient.Databases["FamilyDatabase"].DeleteAsync();

            Console.WriteLine("Deleted Database: {0}\n", this.databaseId);

            //Dispose of CosmosClient
            this.cosmosClient.Dispose();
        }
        // </DeleteDatabaseAndCleanupAsync>



    }
 
    public static class ExtensionsForTesting
    {
        public static void Dump(this object obj)
        {
            Console.WriteLine(obj.DumpString());
        }

        public static string DumpString(this object obj)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(obj, Formatting.Indented);
        }
    }
}
